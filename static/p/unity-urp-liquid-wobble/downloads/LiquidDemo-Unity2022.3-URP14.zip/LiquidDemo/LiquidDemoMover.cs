using UnityEngine;

namespace LiquidDemo
{
    [DisallowMultipleComponent]
    public sealed class LiquidDemoMover : MonoBehaviour
    {
        [SerializeField] private bool animate = true;
        [SerializeField, Min(0.1f)] private float speed = 1.25f;
        [SerializeField, Min(0f)] private float moveDistance = 1.15f;
        [SerializeField, Range(0f, 45f)] private float tiltAngle = 16f;

        private Vector3 startPosition;
        private Quaternion startRotation;

        private void Start()
        {
            startPosition = transform.position;
            startRotation = transform.rotation;
        }

        private void Update()
        {
            if (!animate)
                return;

            float time = Time.time * speed;
            transform.position = startPosition + new Vector3(Mathf.Sin(time) * moveDistance, Mathf.Sin(time * 1.7f) * 0.12f, 0f);
            transform.rotation = startRotation * Quaternion.Euler(Mathf.Sin(time * 0.8f) * tiltAngle * 0.35f, 0f, Mathf.Sin(time * 1.15f) * tiltAngle);
        }
    }
}
