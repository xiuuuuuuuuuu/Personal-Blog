[CmdletBinding()]
param(
    [string]$ProjectPath,
    [string]$EditorPath,
    [string]$SkillDirectory,
    [ValidateRange(30,900)][int]$TimeoutSeconds = 600
)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$OutputEncoding = [Text.UTF8Encoding]::new($false)
$Installed = $false
$BackupPath = $null
$Phase = 'validate_bundle'
$InstallMutex = $null
$MutexAcquired = $false
try {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT -or -not [Environment]::Is64BitOperatingSystem) { throw 'This distribution requires Windows x64.' }
    $Source = Join-Path $PSScriptRoot 'unity-true-cli'
    if (-not (Test-Path -LiteralPath $Source)) { $Source = Join-Path $PSScriptRoot 'skill' }
    . (Join-Path $Source 'scripts/UnityContext.ps1')
    $SourceContext = Get-UnityToolContext
    $Source = [IO.Path]::GetFullPath($Source).TrimEnd('\','/')
    if (-not $SkillDirectory) {
        $CodexRoot = if ($env:CODEX_HOME) { $env:CODEX_HOME } else { Join-Path $env:USERPROFILE '.codex' }
        $SkillDirectory = Join-Path $CodexRoot 'skills/unity-true-cli'
    }
    $Target = [IO.Path]::GetFullPath($SkillDirectory).TrimEnd('\','/')
    if ([IO.Path]::GetFileName($Target) -ne 'unity-true-cli') { throw '-SkillDirectory must end with unity-true-cli (the complete skill folder, not its parent).' }
    if ($Source.StartsWith($Target + '\',[StringComparison]::OrdinalIgnoreCase) -or $Target.StartsWith($Source + '\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Source and destination must not contain one another.' }
    $TargetParent = Split-Path $Target -Parent
    # Check the entire existing ancestor chain before creating or replacing directories.
    $Ancestor = $Target
    while ($Ancestor) {
        if (Test-Path -LiteralPath $Ancestor) {
            if (((Get-Item -LiteralPath $Ancestor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Skill installation path contains a junction or symbolic link: $Ancestor" }
        }
        $Ancestor = Split-Path $Ancestor -Parent
    }
    $Hasher = [Security.Cryptography.SHA256]::Create()
    try { $TargetKey = [BitConverter]::ToString($Hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($Target.ToLowerInvariant()))).Replace('-','') }
    finally { $Hasher.Dispose() }
    $InstallMutex = [Threading.Mutex]::new($false, ('Local\UnityTrueCliSkill-' + $TargetKey))
    try { $MutexAcquired = $InstallMutex.WaitOne([TimeSpan]::FromSeconds(120)) }
    catch [Threading.AbandonedMutexException] { $MutexAcquired = $true }
    if (-not $MutexAcquired) { throw 'Another installation is publishing this skill directory. Inspect its result before retrying.' }
    $Phase = 'install_skill'
    $Same = $Source -eq $Target
    if (-not $Same -and (Test-Path -LiteralPath (Join-Path $Target 'bundle-manifest.json'))) {
        $Same = (Get-UnityFileHash (Join-Path $Target 'bundle-manifest.json')) -eq (Get-UnityFileHash (Join-Path $Source 'bundle-manifest.json'))
        if ($Same -and @(Get-ChildItem -LiteralPath $Target -File -Recurse -Force).Count -ne (@($SourceContext.Manifest.files).Count + 1)) { $Same = $false }
        if ($Same) {
            foreach ($File in $SourceContext.Manifest.files) {
                $ExistingFile = Join-Path $Target $File.path
                if (-not (Test-Path -LiteralPath $ExistingFile -PathType Leaf) -or (Get-UnityFileHash $ExistingFile) -ne $File.sha256) { $Same = $false; break }
            }
        }
    }
    if (-not $Same) {
        $Parent = Split-Path $Target -Parent
        [IO.Directory]::CreateDirectory($Parent) | Out-Null
        do { $InstallId = [Guid]::NewGuid().ToString('N').Substring(0,8); $Stage = Join-Path $Parent ('.utc-' + $InstallId) } while (Test-Path -LiteralPath $Stage)
        New-Item -ItemType Directory -Path $Stage -ErrorAction Stop | Out-Null
        foreach ($Item in Get-ChildItem -LiteralPath $Source -Force) { Copy-Item -LiteralPath $Item.FullName -Destination $Stage -Recurse -ErrorAction Stop }
        foreach ($File in $SourceContext.Manifest.files) {
            if ((Get-UnityFileHash (Join-Path $Stage $File.path)) -ne $File.sha256) { throw "Staged skill failed integrity: $($File.path)" }
        }
        if ((Get-UnityFileHash (Join-Path $Stage 'bundle-manifest.json')) -ne (Get-UnityFileHash (Join-Path $Source 'bundle-manifest.json'))) { throw 'Staged manifest differs from source.' }
        if (Test-Path -LiteralPath $Target) {
            $BackupBase = Split-Path $Parent -Parent
            if (-not $BackupBase) { $BackupBase = $Parent }
            $BackupBase = Join-Path $BackupBase 'unity-cli-skill-backups'
            $BackupAncestor = $BackupBase
            while ($BackupAncestor) {
                if (Test-Path -LiteralPath $BackupAncestor) {
                    if (((Get-Item -LiteralPath $BackupAncestor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Skill backup path contains a junction or symbolic link: $BackupAncestor" }
                }
                $BackupAncestor = Split-Path $BackupAncestor -Parent
            }
            [IO.Directory]::CreateDirectory($BackupBase) | Out-Null
            do { $BackupPath = Join-Path $BackupBase ('utc-' + [Guid]::NewGuid().ToString('N').Substring(0,8)) } while (Test-Path -LiteralPath $BackupPath)
            [IO.Directory]::Move($Target, $BackupPath)
        }
        try { [IO.Directory]::Move($Stage, $Target) }
        catch {
            if ($BackupPath -and -not (Test-Path -LiteralPath $Target)) { [IO.Directory]::Move($BackupPath, $Target) }
            throw
        }
    }
    $Installed = $true
    $InstallMutex.ReleaseMutex()
    $MutexAcquired = $false
    $Ready = $null
    if ($ProjectPath) {
        $Phase = 'prepare_project'
        $Entry = Join-Path $Target 'scripts/Start-UnityTask.ps1'
        $Quote = { param($Value) "'" + ([string]$Value).Replace("'","''") + "'" }
        $Code = '& ' + (& $Quote $Entry) + ' -ProjectPath ' + (& $Quote $ProjectPath) + ' -PrepareOnly'
        if ($EditorPath) { $Code += ' -EditorPath ' + (& $Quote $EditorPath) }
        $Encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($Code))
        $Start = [Diagnostics.ProcessStartInfo]::new()
        $Start.FileName = Join-Path $env:WINDIR 'System32/WindowsPowerShell/v1.0/powershell.exe'
        $Start.Arguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand ' + $Encoded
        $Start.UseShellExecute = $false
        $Start.CreateNoWindow = $true
        $Start.RedirectStandardOutput = $true
        $Start.RedirectStandardError = $true
        $Start.StandardOutputEncoding = [Text.Encoding]::UTF8
        $Start.StandardErrorEncoding = [Text.Encoding]::UTF8
        $Process = [Diagnostics.Process]::Start($Start)
        $Stdout = $Process.StandardOutput.ReadToEndAsync()
        $Stderr = $Process.StandardError.ReadToEndAsync()
        if (-not $Process.WaitForExit($TimeoutSeconds * 1000)) { throw 'Project preparation is still running. The skill is installed; inspect the original project Temp/UnityTrueCLI receipts before retrying. Do not submit another installation.' }
        $Body = $Stdout.GetAwaiter().GetResult()
        $ErrorBody = $Stderr.GetAwaiter().GetResult()
        $Ready = $Body | ConvertFrom-Json
        if ($Process.ExitCode -ne 0 -or $Ready.success -ne $true) {
            $Reason = if ($Ready.errors) { ($Ready.errors | ForEach-Object { $_.message }) -join '; ' } else { $ErrorBody }
            throw "Skill installed; project preparation did not succeed: $Reason"
        }
        $Process.Dispose()
    }
    [ordered]@{success=$true;bundleVersion=$SourceContext.Manifest.bundle_version;skillDirectory=$Target;installed=$Installed;changed=(-not $Same);backupPath=$BackupPath;projectReady=($null -ne $Ready);context=$(if($Ready){$Ready.context}else{$null});next=$(if($Ready){'Use the installed skill Start-UnityTask.ps1 to discover a task or exact command.'}else{'Tell your AI the Unity project path and invoke $unity-true-cli. Restart the AI session if newly installed skills are not discovered.'})} | ConvertTo-Json -Depth 10 -Compress
}
catch {
    [ordered]@{success=$false;phase=$Phase;skillInstalled=$Installed;backupPath=$BackupPath;errors=@(@{code='UNITY_CLI_INSTALL_FAILED';message=$_.Exception.Message})} | ConvertTo-Json -Depth 6 -Compress
    exit 1
}
finally {
    if ($InstallMutex) {
        if ($MutexAcquired) { $InstallMutex.ReleaseMutex() }
        $InstallMutex.Dispose()
    }
}
