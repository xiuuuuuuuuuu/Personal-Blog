using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SimpleSOAudio
{
    public sealed class SimpleSOAudioManager : MonoBehaviour
    {
        private const string SETTINGS_RESOURCE_PATH = "SimpleAudioSettings";
        private const string LIBRARY_RESOURCE_PATH = "SimpleAudioLibrary";
        private const string KEY_MASTER_VOLUME = "SimpleSOAudio_MasterVolume";
        private const string KEY_BGM_VOLUME = "SimpleSOAudio_BgmVolume";
        private const string KEY_SFX_VOLUME = "SimpleSOAudio_SfxVolume";

        private static SimpleSOAudioManager instance;

        public static SimpleSOAudioManager Instance
        {
            get
            {
                if (instance == null)
                {
#if UNITY_2023_1_OR_NEWER
                    instance = FindFirstObjectByType<SimpleSOAudioManager>();
#else
                    instance = FindObjectOfType<SimpleSOAudioManager>();
#endif
                    if (instance == null)
                    {
                        GameObject go = new GameObject("[SimpleSOAudioManager]");
                        instance = go.AddComponent<SimpleSOAudioManager>();
                    }
                }

                return instance;
            }
        }

        [Header("Config")]
        [SerializeField] private SimpleSOAudioSettings settings;
        [SerializeField] private SimpleSOAudioLibrary library;

        private readonly List<AudioSource> sfx_sources = new List<AudioSource>();
        private AudioSource bgm_source;
        private int next_sfx_index;
        private Coroutine bgm_fade;

        public SimpleSOAudioSettings Settings => settings;
        public SimpleSOAudioLibrary Library => library;

        private void Awake()
        {
            if (instance != null && instance != this)
            {
                Destroy(gameObject);
                return;
            }

            instance = this;
            DontDestroyOnLoad(gameObject);
            Initialize();
        }

        private void Initialize()
        {
            if (settings == null)
            {
                settings = Resources.Load<SimpleSOAudioSettings>(SETTINGS_RESOURCE_PATH);
            }

            if (library == null)
            {
                library = Resources.Load<SimpleSOAudioLibrary>(LIBRARY_RESOURCE_PATH);
            }

            if (settings == null)
            {
                settings = ScriptableObject.CreateInstance<SimpleSOAudioSettings>();
                Debug.LogWarning("[SimpleSOAudioManager] Missing SimpleAudioSettings asset. Runtime defaults will be used.");
            }

            LoadVolumes();
            CreateBgmSource();
            CreateInitialSfxSources();
            ApplyVolumes();
        }

        public void PlayBGM(string id, bool loop = true, float fade_time = 0f)
        {
            if (!TryGetEntry(id, out SimpleSOAudioEntry entry))
            {
                return;
            }

            PlayBGM(entry.clip, loop, fade_time, entry.volume);
        }

        public void PlayBGM(AudioClip clip, bool loop = true, float fade_time = 0f, float volume_multiplier = 1f)
        {
            if (clip == null)
            {
                Debug.LogWarning("[SimpleSOAudioManager] Tried to play a null BGM clip.");
                return;
            }

            StopBgmFade();

            if (fade_time <= 0f)
            {
                bgm_source.clip = clip;
                bgm_source.loop = loop;
                bgm_source.volume = settings.BgmFinalVolume * Mathf.Clamp01(volume_multiplier);
                bgm_source.Play();
                return;
            }

            bgm_fade = StartCoroutine(FadeToBGM(clip, loop, fade_time, Mathf.Clamp01(volume_multiplier)));
        }

        public void StopBGM(float fade_time = 0f)
        {
            StopBgmFade();

            if (fade_time <= 0f || !bgm_source.isPlaying)
            {
                bgm_source.Stop();
                bgm_source.clip = null;
                return;
            }

            bgm_fade = StartCoroutine(FadeOutBGM(fade_time));
        }

        public void PauseBGM()
        {
            bgm_source.Pause();
        }

        public void ResumeBGM()
        {
            bgm_source.UnPause();
        }

        public AudioSource PlaySFX(string id)
        {
            if (!TryGetEntry(id, out SimpleSOAudioEntry entry))
            {
                return null;
            }

            return PlaySFX(entry.clip, entry.volume, RandomPitch(entry.pitch_range));
        }

        public AudioSource PlaySFXAtPosition(string id, Vector3 position)
        {
            if (!TryGetEntry(id, out SimpleSOAudioEntry entry))
            {
                return null;
            }

            return PlaySFXAtPosition(entry.clip, position, entry.volume, RandomPitch(entry.pitch_range));
        }

        public AudioSource PlaySFX(AudioClip clip, float volume_multiplier = 1f, float pitch = 1f)
        {
            return PlaySFXInternal(clip, transform.position, false, volume_multiplier, pitch);
        }

        public AudioSource PlaySFXAtPosition(AudioClip clip, Vector3 position, float volume_multiplier = 1f, float pitch = 1f)
        {
            return PlaySFXInternal(clip, position, true, volume_multiplier, pitch);
        }

        public void SetMasterVolume(float volume)
        {
            settings.master_volume = Mathf.Clamp01(volume);
            ApplyVolumes();
            SaveVolumes();
        }

        public void SetBGMVolume(float volume)
        {
            settings.bgm_volume = Mathf.Clamp01(volume);
            ApplyVolumes();
            SaveVolumes();
        }

        public void SetSFXVolume(float volume)
        {
            settings.sfx_volume = Mathf.Clamp01(volume);
            ApplyVolumes();
            SaveVolumes();
        }

        public void StopAllSFX()
        {
            foreach (AudioSource source in sfx_sources)
            {
                if (source != null)
                {
                    source.Stop();
                }
            }
        }

        public void StopAll()
        {
            StopBGM();
            StopAllSFX();
        }

        public void SaveVolumes()
        {
            PlayerPrefs.SetFloat(KEY_MASTER_VOLUME, settings.master_volume);
            PlayerPrefs.SetFloat(KEY_BGM_VOLUME, settings.bgm_volume);
            PlayerPrefs.SetFloat(KEY_SFX_VOLUME, settings.sfx_volume);
            PlayerPrefs.Save();
        }

        public void LoadVolumes()
        {
            settings.master_volume = PlayerPrefs.GetFloat(KEY_MASTER_VOLUME, settings.master_volume);
            settings.bgm_volume = PlayerPrefs.GetFloat(KEY_BGM_VOLUME, settings.bgm_volume);
            settings.sfx_volume = PlayerPrefs.GetFloat(KEY_SFX_VOLUME, settings.sfx_volume);
        }

        private bool TryGetEntry(string id, out SimpleSOAudioEntry entry)
        {
            entry = null;

            if (library == null)
            {
                Debug.LogWarning("[SimpleSOAudioManager] Missing SimpleAudioLibrary asset.");
                return false;
            }

            if (!library.TryGet(id, out entry) || entry == null || entry.clip == null)
            {
                Debug.LogWarning($"[SimpleSOAudioManager] Missing audio id or clip: {id}");
                return false;
            }

            return true;
        }

        private AudioSource PlaySFXInternal(AudioClip clip, Vector3 position, bool is_3d, float volume_multiplier, float pitch)
        {
            if (clip == null)
            {
                Debug.LogWarning("[SimpleSOAudioManager] Tried to play a null SFX clip.");
                return null;
            }

            AudioSource source = GetSfxSource();
            source.transform.position = position;
            source.spatialBlend = is_3d ? 1f : 0f;
            source.minDistance = settings.min_distance;
            source.maxDistance = settings.max_distance;
            source.rolloffMode = settings.rolloff_mode;
            source.pitch = Mathf.Max(0.01f, pitch);
            source.volume = settings.SfxFinalVolume;
            source.PlayOneShot(clip, Mathf.Clamp01(volume_multiplier));
            return source;
        }

        private void CreateBgmSource()
        {
            if (bgm_source != null)
            {
                return;
            }

            bgm_source = gameObject.AddComponent<AudioSource>();
            bgm_source.playOnAwake = false;
            bgm_source.loop = true;
            bgm_source.spatialBlend = 0f;
        }

        private void CreateInitialSfxSources()
        {
            while (sfx_sources.Count < settings.initial_sfx_sources)
            {
                CreateSfxSource();
            }
        }

        private AudioSource GetSfxSource()
        {
            foreach (AudioSource source in sfx_sources)
            {
                if (source != null && !source.isPlaying)
                {
                    return source;
                }
            }

            if (settings.expand_pool_when_busy && sfx_sources.Count < settings.max_sfx_sources)
            {
                return CreateSfxSource();
            }

            AudioSource fallback = sfx_sources[next_sfx_index];
            next_sfx_index = (next_sfx_index + 1) % sfx_sources.Count;
            fallback.Stop();
            return fallback;
        }

        private AudioSource CreateSfxSource()
        {
            GameObject go = new GameObject($"SFXSource_{sfx_sources.Count}");
            go.transform.SetParent(transform);

            AudioSource source = go.AddComponent<AudioSource>();
            source.playOnAwake = false;
            source.loop = false;
            source.spatialBlend = 0f;
            source.volume = settings.SfxFinalVolume;
            source.minDistance = settings.min_distance;
            source.maxDistance = settings.max_distance;
            source.rolloffMode = settings.rolloff_mode;

            sfx_sources.Add(source);
            return source;
        }

        private void ApplyVolumes()
        {
            if (bgm_source != null)
            {
                bgm_source.volume = settings.BgmFinalVolume;
            }

            foreach (AudioSource source in sfx_sources)
            {
                if (source != null)
                {
                    source.volume = settings.SfxFinalVolume;
                }
            }
        }

        private static float RandomPitch(Vector2 pitch_range)
        {
            return Mathf.Approximately(pitch_range.x, pitch_range.y)
                ? pitch_range.x
                : Random.Range(pitch_range.x, pitch_range.y);
        }

        private void StopBgmFade()
        {
            if (bgm_fade == null)
            {
                return;
            }

            StopCoroutine(bgm_fade);
            bgm_fade = null;
        }

        private IEnumerator FadeToBGM(AudioClip clip, bool loop, float fade_time, float volume_multiplier)
        {
            if (bgm_source.isPlaying)
            {
                yield return FadeBgmVolume(0f, fade_time * 0.5f);
            }

            bgm_source.clip = clip;
            bgm_source.loop = loop;
            bgm_source.volume = 0f;
            bgm_source.Play();

            yield return FadeBgmVolume(settings.BgmFinalVolume * volume_multiplier, fade_time * 0.5f);
            bgm_fade = null;
        }

        private IEnumerator FadeOutBGM(float fade_time)
        {
            yield return FadeBgmVolume(0f, fade_time);
            bgm_source.Stop();
            bgm_source.clip = null;
            bgm_source.volume = settings.BgmFinalVolume;
            bgm_fade = null;
        }

        private IEnumerator FadeBgmVolume(float target_volume, float duration)
        {
            float start_volume = bgm_source.volume;

            if (duration <= 0f)
            {
                bgm_source.volume = target_volume;
                yield break;
            }

            float time = 0f;
            while (time < duration)
            {
                time += Time.unscaledDeltaTime;
                bgm_source.volume = Mathf.Lerp(start_volume, target_volume, time / duration);
                yield return null;
            }

            bgm_source.volume = target_volume;
        }
    }
}
