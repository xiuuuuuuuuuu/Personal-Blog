[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath($PSScriptRoot)
$rootPrefix = $root.TrimEnd([char[]]'\/') + [IO.Path]::DirectorySeparatorChar
$manifest = Get-Content -LiteralPath (Join-Path $root 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$verified = 0
foreach ($entry in $manifest.files) {
    if ([IO.Path]::IsPathRooted($entry.path)) { throw "Invalid absolute manifest path: $($entry.path)" }
    $path = [IO.Path]::GetFullPath((Join-Path $root $entry.path))
    if (-not $path.StartsWith($rootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Manifest path escapes bundle: $($entry.path)"
    }
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing file: $($entry.path)" }
    $file = Get-Item -LiteralPath $path
    if ($file.Length -ne $entry.bytes) { throw "Size mismatch: $($entry.path)" }
    $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    if ($hash -ne $entry.sha256) { throw "SHA256 mismatch: $($entry.path)" }
    Write-Output "OK  $($entry.path)"
    $verified++
}
if ($verified -eq 0) { throw 'Manifest has no files.' }
Write-Output "PASS: $verified files verified. No installation or Unity operation was performed."
