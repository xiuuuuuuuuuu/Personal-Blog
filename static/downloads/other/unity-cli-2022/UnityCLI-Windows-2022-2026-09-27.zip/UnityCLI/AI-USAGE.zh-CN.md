# 给 AI 的 Unity CLI 调用说明

请先让用户提供或根据当前环境确认下面三个值，不要照抄示例项目路径：

- CLI 目录，例如 `D:\UnityTools\UnityCLI`。
- Unity 项目根目录，例如 `D:\Work\YourProject`。
- 目标 Unity 版本，本包验证范围见 `README.zh-CN.md`。

## 首次连接

1. 先确认目标项目在本机 Unity 编辑器中打开。
2. 使用 CLI 完整路径执行 `--version`。
3. 执行 `command editor_status --project-path <项目路径> --format json --timeout 10`，核对项目和版本。
4. 在自动操作前执行 `command set_autotick --enable true`，同样显式指定项目和超时。
5. 用 `command eval --code 'return UnityEngine.Application.unityVersion;'` 验证实际执行。

CLI 和 Unity 应在同一 Windows 用户的获准环境下访问。若沙箱不能读取本机实例凭据，使用执行工具提供的正常权限审批机制；不得复制旧凭据、关闭认证或扩大凭据文件访问权限。

## 操作与等待

- 每次明确 `--project-path`，避免误操作其他打开的项目。
- 使用公共 `unity.ps1` 时，用 `-ProjectPath` 传项目路径，不要在 `-CliArgs` 再传 `--project-path`。
- 多行 C# 写到项目的 `Tools/UnityCli/` 等 Assets 外目录，用 `run_script` 执行明确的静态入口。
- 检查进程退出码、外层 CLI 结果、内层脚本结果，不要只凭“调用已返回”宣称成功。
- 普通状态查询设置 10–15 秒客户端超时；脚本执行按工作量设置超时，解释超过预期的原因。
- `--timeout` 单位是秒；`run_script --timeout_ms` 单位是毫秒。先看对应命令帮助。
- 超时后先检查编辑器及任务状态，不盲目重试产生副作用的命令；脚本可能仍在继续。
- 遇到弹窗阻塞，告诉用户实际弹窗内容，不自动选择保存或丢弃未知改动。
- 修改项目 C# 后，触发 `recompile` 并查询 `recompile_status`，允许域重载期间短暂断连。
- 长测试使用支持的异步模式并查询 `test_status`；不要为等待而重复启动测试。
- 在进度说明中区分“命令正在执行”“命令已成功，正在检查结果”和“AI 正在分析”。
- 不要用 `unity pipeline install` 替换本地 Unity 2022 适配包，不擅自升级固定版本。

## 示例

```powershell
& 'D:\UnityTools\UnityCLI\bin\unity.exe' command editor_status --project-path 'D:\Work\YourProject' --format json --timeout 10
```

```powershell
& 'D:\UnityTools\UnityCLI\unity.ps1' -ProjectPath 'D:\Work\YourProject' -CliArgs @('command', 'editor_status', '--format', 'json', '--timeout', '10')
```

工具就绪后，继续完成用户的具体 Unity 任务。每次只执行已授权的项目操作，并保留用户已有场景和文件改动。

