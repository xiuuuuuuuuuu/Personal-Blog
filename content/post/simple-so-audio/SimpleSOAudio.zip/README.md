# SimpleSOAudio

一个基于 ScriptableObject 的轻量 Unity 音频管理器，支持 ID 驱动播放、BGM 淡入淡出、SFX 对象池、2D/3D 音效和音量持久化。

## 文件

- `SimpleSOAudioLibrary.cs`：音频条目与 ID 映射库
- `SimpleSOAudioSettings.cs`：音量、SFX 池和 3D 音效设置
- `SimpleSOAudioManager.cs`：全局音频管理器

## 使用

1. 将三个脚本放入 `Assets` 任意目录。
2. 创建 `Simple Audio/Settings` 和 `Simple Audio/Library` 两个资源，并把资源文件分别命名为 `SimpleAudioSettings`、`SimpleAudioLibrary`，放到任意 `Resources` 文件夹下。
3. 在 Library 资源中添加音频条目：填写 `id`、拖入 `AudioClip`，选择 BGM 或 SFX，并设置音量和音调范围。
4. 在首个场景挂载 `SimpleSOAudioManager`，或直接通过 `SimpleSOAudioManager.Instance` 获取自动创建的实例。

```csharp
SimpleSOAudioManager.Instance.PlayBGM("bgm_main", fade_time: 1.5f);
SimpleSOAudioManager.Instance.PlaySFX("sfx_click");
SimpleSOAudioManager.Instance.PlaySFXAtPosition("sfx_explosion", transform.position);
SimpleSOAudioManager.Instance.SetSFXVolume(0.8f);
```

## 协议

原项目以 MIT License 开源。
