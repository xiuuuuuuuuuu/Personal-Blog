using UnityEngine;

namespace SimpleSOAudio
{
    [CreateAssetMenu(fileName = "SimpleAudioSettings", menuName = "Simple Audio/Settings")]
    public sealed class SimpleSOAudioSettings : ScriptableObject
    {
        [Header("Volume")]
        [Range(0f, 1f)] public float master_volume = 1f;
        [Range(0f, 1f)] public float bgm_volume = 1f;
        [Range(0f, 1f)] public float sfx_volume = 1f;

        [Header("SFX Pool")]
        [Min(1)] public int initial_sfx_sources = 8;
        public bool expand_pool_when_busy = true;
        [Min(1)] public int max_sfx_sources = 16;

        [Header("3D SFX")]
        [Min(0.01f)] public float min_distance = 1f;
        [Min(0.01f)] public float max_distance = 25f;
        public AudioRolloffMode rolloff_mode = AudioRolloffMode.Logarithmic;

        public float BgmFinalVolume => master_volume * bgm_volume;
        public float SfxFinalVolume => master_volume * sfx_volume;

        private void OnValidate()
        {
            master_volume = Mathf.Clamp01(master_volume);
            bgm_volume = Mathf.Clamp01(bgm_volume);
            sfx_volume = Mathf.Clamp01(sfx_volume);
            initial_sfx_sources = Mathf.Max(1, initial_sfx_sources);
            max_sfx_sources = Mathf.Max(initial_sfx_sources, max_sfx_sources);
            min_distance = Mathf.Max(0.01f, min_distance);
            max_distance = Mathf.Max(min_distance, max_distance);
        }
    }
}
