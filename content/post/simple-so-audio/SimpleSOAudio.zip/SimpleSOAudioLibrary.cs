using System;
using System.Collections.Generic;
using UnityEngine;

namespace SimpleSOAudio
{
    public enum SimpleSOAudioType
    {
        BGM,
        SFX
    }

    [Serializable]
    public sealed class SimpleSOAudioEntry
    {
        public string id;
        public AudioClip clip;
        public SimpleSOAudioType type = SimpleSOAudioType.SFX;
        [Range(0f, 1f)] public float volume = 1f;
        public Vector2 pitch_range = Vector2.one;
    }

    [CreateAssetMenu(fileName = "SimpleAudioLibrary", menuName = "Simple Audio/Library")]
    public sealed class SimpleSOAudioLibrary : ScriptableObject
    {
        [SerializeField] private List<SimpleSOAudioEntry> entries = new List<SimpleSOAudioEntry>();

        private Dictionary<string, SimpleSOAudioEntry> lookup;

        public IReadOnlyList<SimpleSOAudioEntry> Entries => entries;

        public bool TryGet(string id, out SimpleSOAudioEntry entry)
        {
            if (lookup == null)
            {
                RebuildLookup();
            }

            return lookup.TryGetValue(id, out entry);
        }

        private void RebuildLookup()
        {
            lookup = new Dictionary<string, SimpleSOAudioEntry>();

            foreach (SimpleSOAudioEntry entry in entries)
            {
                if (entry == null || string.IsNullOrWhiteSpace(entry.id))
                {
                    continue;
                }

                lookup[entry.id] = entry;
            }
        }

        private void OnValidate()
        {
            lookup = null;
        }
    }
}
