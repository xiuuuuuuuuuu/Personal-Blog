Shader "LiquidDemo/URP Liquid"
{
    Properties
    {
        [HDR] _BaseColor("Liquid Color", Color) = (0.02, 0.45, 0.8, 0.82)
        [HDR] _TopColor("Surface Color", Color) = (0.12, 0.75, 1.0, 0.95)
        [HDR] _FoamColor("Foam Color", Color) = (0.65, 0.95, 1.0, 1.0)
        _FoamWidth("Foam Width", Range(0.001, 0.15)) = 0.035
        [HDR] _RimColor("Rim Color", Color) = (0.12, 0.65, 1.0, 0.65)
        _RimPower("Rim Power", Range(0.5, 8.0)) = 3.0
        _WaveFrequency("Wave Frequency", Range(0.0, 20.0)) = 7.0
        _WaveAmplitude("Wave Amplitude", Range(0.0, 0.08)) = 0.018
        [HideInInspector] _FillPosition("Fill Position", Vector) = (0, 0, 0, 0)
        [HideInInspector] _WobbleX("Wobble X", Float) = 0
        [HideInInspector] _WobbleZ("Wobble Z", Float) = 0
    }

    SubShader
    {
        Tags
        {
            "RenderType" = "Transparent"
            "Queue" = "Transparent-10"
            "RenderPipeline" = "UniversalPipeline"
        }

        Pass
        {
            Name "LiquidForward"
            Tags { "LightMode" = "UniversalForward" }

            Cull Off
            ZWrite On
            Blend SrcAlpha OneMinusSrcAlpha

            HLSLPROGRAM
            #pragma target 3.0
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_fog

            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _BaseColor;
                half4 _TopColor;
                half4 _FoamColor;
                half4 _RimColor;
                float4 _FillPosition;
                float _FoamWidth;
                float _RimPower;
                float _WaveFrequency;
                float _WaveAmplitude;
                float _WobbleX;
                float _WobbleZ;
            CBUFFER_END

            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS : NORMAL;
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float3 positionWS : TEXCOORD0;
                half3 normalWS : TEXCOORD1;
                half fogFactor : TEXCOORD2;
            };

            Varyings Vert(Attributes input)
            {
                Varyings output;
                VertexPositionInputs positionInputs = GetVertexPositionInputs(input.positionOS.xyz);
                output.positionCS = positionInputs.positionCS;
                output.positionWS = positionInputs.positionWS;
                output.normalWS = TransformObjectToWorldNormal(input.normalOS);
                output.fogFactor = ComputeFogFactor(positionInputs.positionCS.z);
                return output;
            }

            half4 Frag(Varyings input, bool isFrontFace : SV_IsFrontFace) : SV_Target
            {
                float3 relativePosition = input.positionWS - _FillPosition.xyz;
                float movement = saturate(abs(_WobbleX) + abs(_WobbleZ));
                float wave = sin((relativePosition.x + relativePosition.z) * _WaveFrequency + _Time.y * 2.0)
                           * _WaveAmplitude * movement;
                float surfaceDistance = relativePosition.y
                                      + relativePosition.x * _WobbleX
                                      + relativePosition.z * _WobbleZ
                                      + wave;

                clip(-surfaceDistance);

                float foam = 1.0 - smoothstep(0.0, _FoamWidth, -surfaceDistance);
                half3 viewDirection = GetWorldSpaceNormalizeViewDir(input.positionWS);
                half3 normalDirection = normalize(input.normalWS);
                half rim = pow(1.0h - saturate(dot(normalDirection, viewDirection)), _RimPower);

                half4 sideColor = lerp(_BaseColor, _FoamColor, foam);
                sideColor.rgb += _RimColor.rgb * rim * _RimColor.a;
                half4 finalColor = isFrontFace ? sideColor : lerp(_TopColor, _FoamColor, foam * 0.65);
                finalColor.rgb = MixFog(finalColor.rgb, input.fogFactor);
                return finalColor;
            }
            ENDHLSL
        }
    }
}
