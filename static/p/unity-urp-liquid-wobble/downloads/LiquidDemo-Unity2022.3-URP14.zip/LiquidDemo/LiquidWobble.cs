using UnityEngine;

namespace LiquidDemo
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Renderer), typeof(MeshFilter))]
    public sealed class LiquidWobble : MonoBehaviour
    {
        [Header("Liquid Level")]
        [SerializeField, Range(0f, 1f)] private float fillAmount = 0.62f;

        [Header("Motion")]
        [SerializeField, Range(0f, 0.25f)] private float maxWobble = 0.10f;
        [SerializeField, Min(0.1f)] private float wobbleSpeed = 2.2f;
        [SerializeField, Min(0.1f)] private float recovery = 2.0f;
        [SerializeField, Min(0f)] private float motionSensitivity = 0.035f;

        private static readonly int FillPositionId = Shader.PropertyToID("_FillPosition");
        private static readonly int WobbleXId = Shader.PropertyToID("_WobbleX");
        private static readonly int WobbleZId = Shader.PropertyToID("_WobbleZ");

        // Unity can discard non-serialized managed objects during an editor domain reload.
        // Recreate this cache lazily instead of relying on a field initializer.
        [System.NonSerialized] private MaterialPropertyBlock properties;
        private Renderer targetRenderer;
        private MeshFilter meshFilter;
        private Vector3 previousPosition;
        private Quaternion previousRotation;
        private float wobbleImpulseX;
        private float wobbleImpulseZ;
        private float phase;
        private double previousEditorTime;

        private void OnEnable()
        {
            CacheComponents();
            EnsurePropertyBlock();
            previousPosition = transform.position;
            previousRotation = transform.rotation;
#if UNITY_EDITOR
            previousEditorTime = UnityEditor.EditorApplication.timeSinceStartup;
#endif
            ApplyProperties(0f, 0f);
        }

        private void OnValidate()
        {
            CacheComponents();
            ApplyProperties(0f, 0f);
        }

        private void Update()
        {
            CacheComponents();
            if (targetRenderer == null || meshFilter == null || meshFilter.sharedMesh == null)
                return;

            float deltaTime = GetDeltaTime();
            if (deltaTime <= 0.00001f)
            {
                ApplyProperties(wobbleImpulseX, wobbleImpulseZ);
                return;
            }

            Vector3 velocity = (transform.position - previousPosition) / deltaTime;
            Vector3 angularVelocity = CalculateAngularVelocity(previousRotation, transform.rotation, deltaTime);

            wobbleImpulseX += (-velocity.x + angularVelocity.z * 0.18f) * motionSensitivity;
            wobbleImpulseZ += (-velocity.z - angularVelocity.x * 0.18f) * motionSensitivity;
            wobbleImpulseX = Mathf.Clamp(wobbleImpulseX, -maxWobble, maxWobble);
            wobbleImpulseZ = Mathf.Clamp(wobbleImpulseZ, -maxWobble, maxWobble);

            float damping = Mathf.Exp(-recovery * deltaTime);
            wobbleImpulseX *= damping;
            wobbleImpulseZ *= damping;
            phase += deltaTime * wobbleSpeed * Mathf.PI * 2f;

            float pulse = Mathf.Sin(phase);
            ApplyProperties(wobbleImpulseX * pulse, wobbleImpulseZ * pulse);

            previousPosition = transform.position;
            previousRotation = transform.rotation;
        }

        private void ApplyProperties(float wobbleX, float wobbleZ)
        {
            if (targetRenderer == null || meshFilter == null || meshFilter.sharedMesh == null)
                return;

            EnsurePropertyBlock();

            Bounds bounds = meshFilter.sharedMesh.bounds;
            Vector3 centerWS = transform.TransformPoint(bounds.center);
            float worldHeight = bounds.size.y * Mathf.Abs(transform.lossyScale.y);
            float heightOffset = Mathf.Lerp(-worldHeight * 0.5f, worldHeight * 0.5f, fillAmount);
            Vector3 fillPosition = centerWS + Vector3.up * heightOffset;

            targetRenderer.GetPropertyBlock(properties);
            properties.SetVector(FillPositionId, fillPosition);
            properties.SetFloat(WobbleXId, wobbleX);
            properties.SetFloat(WobbleZId, wobbleZ);
            targetRenderer.SetPropertyBlock(properties);
        }

        private void EnsurePropertyBlock()
        {
            if (properties == null)
                properties = new MaterialPropertyBlock();
        }

        private void CacheComponents()
        {
            if (targetRenderer == null)
                targetRenderer = GetComponent<Renderer>();
            if (meshFilter == null)
                meshFilter = GetComponent<MeshFilter>();
        }

        private float GetDeltaTime()
        {
            if (Application.isPlaying)
                return Time.unscaledDeltaTime;

#if UNITY_EDITOR
            double now = UnityEditor.EditorApplication.timeSinceStartup;
            float delta = (float)(now - previousEditorTime);
            previousEditorTime = now;
            return Mathf.Min(delta, 0.05f);
#else
            return 0f;
#endif
        }

        private static Vector3 CalculateAngularVelocity(Quaternion from, Quaternion to, float deltaTime)
        {
            Quaternion delta = to * Quaternion.Inverse(from);
            delta.ToAngleAxis(out float angleDegrees, out Vector3 axis);
            if (angleDegrees > 180f)
                angleDegrees -= 360f;
            if (float.IsNaN(axis.x) || float.IsInfinity(axis.x) || axis.sqrMagnitude < 0.0001f)
                return Vector3.zero;
            return axis.normalized * (angleDegrees * Mathf.Deg2Rad / deltaTime);
        }
    }
}
