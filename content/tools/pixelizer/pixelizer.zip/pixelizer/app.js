"use strict";

const DEFAULT_PALETTE = ["#1B1920", "#5B566B", "#97555B", "#E67E7E", "#DBF0F0"];
const MAX_PALETTE = 12;
const IMAGE_MAX_SIZE = 5 * 1024 * 1024;
const VIDEO_MAX_SIZE = 200 * 1024 * 1024;
const ACCEPTED_TYPES = ["image/jpeg", "image/png", "image/webp"];
const VIDEO_TYPES = ["video/mp4", "video/webm", "video/ogg"];

const BAYER_8 = [
  [0, 32, 8, 40, 2, 34, 10, 42],
  [48, 16, 56, 24, 50, 18, 58, 26],
  [12, 44, 4, 36, 14, 46, 6, 38],
  [60, 28, 52, 20, 62, 30, 54, 22],
  [3, 35, 11, 43, 1, 33, 9, 41],
  [51, 19, 59, 27, 49, 17, 57, 25],
  [15, 47, 7, 39, 13, 45, 5, 37],
  [63, 31, 55, 23, 61, 29, 53, 21]
];

const state = {
  mode: "image",
  file: null,
  originalUrl: "",
  resultUrl: "",
  palette: DEFAULT_PALETTE.slice(),
  options: { pixelWidth: 256, outputWidth: 512, strength: 15, blurRadius: 0.4, autoContrast: true },
  natural: { width: 0, height: 0 },
  convertToken: 0,
  video: { file: null, url: "", duration: 0, width: 0, height: 0, small: null }
};

const $ = function (id) { return document.getElementById(id); };

const els = {
  imageModeBtn: $("imageModeBtn"),
  videoModeBtn: $("videoModeBtn"),
  dropzone: $("dropzone"),
  dropHint: $("dropHint"),
  fileInput: $("fileInput"),
  sourceMeta: $("sourceMeta"),
  sourcePreview: $("sourcePreview"),
  sourceVideo: $("sourceVideo"),
  sourceName: $("sourceName"),
  sourceSize: $("sourceSize"),
  chooseAgain: $("chooseAgain"),
  chooseOther: $("chooseOther"),
  resultPreview: $("resultPreview"),
  videoResult: $("videoResult"),
  resultEmpty: $("resultEmpty"),
  converting: $("converting"),
  resultSize: $("resultSize"),
  errorMsg: $("errorMsg"),
  paletteList: $("paletteList"),
  resetPalette: $("resetPalette"),
  extractPalette: $("extractPalette"),
  addColorHex: $("addColorHex"),
  addColor: $("addColor"),
  downloadBtn: $("downloadBtn"),
  imageExportRow: $("imageExportRow"),
  videoExportRow: $("videoExportRow"),
  preserveAudio: $("preserveAudio"),
  exportWebMBtn: $("exportWebMBtn"),
  exportMp4Btn: $("exportMp4Btn"),
  exportFrameBtn: $("exportFrameBtn"),
  videoStatus: $("videoStatus"),
  exportProgress: $("exportProgress"),
  exportProgressText: $("exportProgressText"),
  outputSizeLabel: $("outputSizeLabel"),
  pixelWidth: $("pixelWidth"),
  outputWidth: $("outputWidth"),
  strength: $("strength"),
  blur: $("blur"),
  autoContrast: $("autoContrast"),
  pixelWidthVal: $("pixelWidthVal"),
  outputWidthVal: $("outputWidthVal"),
  strengthVal: $("strengthVal"),
  blurVal: $("blurVal")
};

state.video.element = els.sourceVideo;

function clampByte(value) {
  return Math.max(0, Math.min(255, Math.round(value)));
}

function hexToRgb(hex) {
  const v = String(hex || "").replace("#", "");
  const full = v.length === 3 ? v.split("").map(function (c) { return c + c; }).join("") : v;
  return [
    parseInt(full.slice(0, 2), 16),
    parseInt(full.slice(2, 4), 16),
    parseInt(full.slice(4, 6), 16)
  ];
}

function rgbToHex(r, g, b) {
  const to2 = function (n) {
    const s = clampByte(n).toString(16);
    return s.length === 1 ? "0" + s : s;
  };
  return "#" + to2(r) + to2(g) + to2(b);
}

function normalizeHex(value) {
  let v = String(value || "").trim().toLowerCase();
  if (v.charAt(0) !== "#") v = "#" + v;
  if (/^#[0-9a-f]{3}$/.test(v)) {
    v = "#" + v.charAt(1) + v.charAt(1) + v.charAt(2) + v.charAt(2) + v.charAt(3) + v.charAt(3);
  }
  if (!/^#[0-9a-f]{6}$/.test(v)) return null;
  return v.toUpperCase();
}

function rgbToHsv(r, g, b) {
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const delta = max - min;
  let hue = 0;
  if (delta) {
    if (max === r) hue = ((g - b) / delta) % 6 * 60;
    else if (max === g) hue = 60 * ((b - r) / delta + 2);
    else hue = 60 * ((r - g) / delta + 4);
  }
  if (hue < 0) hue += 360;
  return { hue: hue, saturation: max ? delta / max : 0, value: max / 255 };
}

function hueDist(a, b) {
  const d = Math.abs(a - b);
  return Math.min(d, 360 - d);
}

function luma(rgb) {
  return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
}

function percentileColor(pixels, t) {
  if (!pixels || !pixels.length) return [0, 0, 0];
  const sorted = pixels.slice().sort(function (a, b) { return luma(a) - luma(b); });
  return sorted[Math.round((sorted.length - 1) * t)];
}

function loadImage(file) {
  return new Promise(function (resolve, reject) {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = function () {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = function () {
      URL.revokeObjectURL(url);
      reject(new Error("图片无效或已损坏"));
    };
    img.src = url;
  });
}

function loadVideoMeta(video) {
  return new Promise(function (resolve, reject) {
    if (video.readyState >= 1 && video.videoWidth) { resolve(video); return; }
    let finished = false;
    function cleanup() {
      video.removeEventListener("loadedmetadata", onMeta);
      video.removeEventListener("error", onError);
    }
    function onMeta() {
      if (finished) return;
      finished = true;
      cleanup();
      resolve(video);
    }
    function onError() {
      if (finished) return;
      finished = true;
      cleanup();
      reject(new Error("视频无法读取"));
    }
    video.addEventListener("loadedmetadata", onMeta);
    video.addEventListener("error", onError);
  });
}

function waitSeeked(video, target) {
  return new Promise(function (resolve) {
    let done = false;
    const timer = setTimeout(finish, 900);
    function finish() {
      if (done) return;
      done = true;
      clearTimeout(timer);
      video.removeEventListener("seeked", onSeek);
      resolve();
    }
    function onSeek() { finish(); }
    video.addEventListener("seeked", onSeek);
    video.currentTime = target;
  });
}

function extractPaletteFromImageData(data, count) {
  count = count || 3;
  const buckets = Array.from({ length: 24 }, function () {
    return { weight: 0, red: 0, green: 0, blue: 0, pixels: [] };
  });

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const hsv = rgbToHsv(r, g, b);
    if (hsv.saturation < 0.16 || hsv.value < 0.08) continue;
    const bucket = buckets[Math.floor(hsv.hue / 15) % 24];
    bucket.weight += 1;
    bucket.red += r;
    bucket.green += g;
    bucket.blue += b;
    bucket.pixels.push([r, g, b]);
  }

  const weighted = buckets.map(function (bucket, idx) {
    const hue = 15 * idx + 7.5;
    let familyWeight = 0;
    for (let j = 0; j < 24; j++) {
      if (hueDist(hue, 15 * j + 7.5) < 45) familyWeight += buckets[j].weight;
    }
    return { weight: bucket.weight, red: bucket.red, green: bucket.green, blue: bucket.blue, pixels: bucket.pixels, hue: hue, familyWeight: familyWeight };
  }).sort(function (a, b) { return b.familyWeight - a.familyWeight; });

  const families = [];
  const maxFamilies = Math.min(2, count);

  for (const bucket of weighted) {
    if (!bucket.familyWeight) break;
    if (families.some(function (f) { return hueDist(f.hue, bucket.hue) < 60; })) continue;
    const family = { hue: bucket.hue, weight: 0, red: 0, green: 0, blue: 0, pixels: [] };
    for (let j = 0; j < 24; j++) {
      const otherHue = 15 * j + 7.5;
      if (hueDist(bucket.hue, otherHue) < 45) {
        const other = buckets[j];
        family.weight += other.weight;
        family.red += other.red;
        family.green += other.green;
        family.blue += other.blue;
        family.pixels.push.apply(family.pixels, other.pixels);
      }
    }
    families.push(family);
    if (families.length === maxFamilies) break;
  }

  let colors = [];
  if (count >= 3 && families.length) {
    const sorted = families.slice().sort(function (a, b) { return b.weight - a.weight; });
    const first = sorted[0];
    const second = sorted[1];
    if (second) {
      colors = [percentileColor(first.pixels, 0.3), percentileColor(first.pixels, 0.7), percentileColor(second.pixels, 0.8)];
    } else {
      colors = [0.25, 0.5, 0.75].map(function (t) { return percentileColor(first.pixels, t); });
    }
    colors.sort(function (a, b) { return luma(a) - luma(b); });
  } else if (families.length) {
    const sorted = families.slice().sort(function (a, b) {
      return luma([a.red / a.weight, a.green / a.weight, a.blue / a.weight]) - luma([b.red / b.weight, b.green / b.weight, b.blue / b.weight]);
    });
    colors = sorted.map(function (family, idx) {
      return percentileColor(family.pixels, idx === 0 ? 0.35 : 0.65);
    });
    colors.sort(function (a, b) { return luma(a) - luma(b); });
  }
  return colors;
}

function extractPaletteColors(img, count) {
  const w = img.naturalWidth || img.width;
  const h = img.naturalHeight || img.height;
  const scale = Math.min(1, 192 / Math.max(w, h));
  const tw = Math.max(1, Math.round(w * scale));
  const th = Math.max(1, Math.round(h * scale));
  const canvas = document.createElement("canvas");
  canvas.width = tw;
  canvas.height = th;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, tw, th);
  ctx.drawImage(img, 0, 0, tw, th);
  return extractPaletteFromImageData(ctx.getImageData(0, 0, tw, th).data, count);
}

function extractPaletteFromVideo(video, count) {
  const w = video.videoWidth || state.video.width;
  const h = video.videoHeight || state.video.height;
  if (!w || !h) return [];
  const scale = Math.min(1, 192 / Math.max(w, h));
  const tw = Math.max(1, Math.round(w * scale));
  const th = Math.max(1, Math.round(h * scale));
  const canvas = document.createElement("canvas");
  canvas.width = tw;
  canvas.height = th;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, tw, th);
  ctx.drawImage(video, 0, 0, tw, th);
  return extractPaletteFromImageData(ctx.getImageData(0, 0, tw, th).data, count);
}

function applyAutoContrast(imageData) {
  const data = imageData.data;
  const total = imageData.width * imageData.height;
  for (let ch = 0; ch < 3; ch++) {
    const hist = new Array(256).fill(0);
    for (let i = 0; i < total; i++) hist[data[i * 4 + ch]]++;
    const clip = Math.floor(total / 100);
    let lowRemain = clip;
    let highRemain = clip;
    for (let v = 0; v < 256 && lowRemain > 0; v++) {
      if (lowRemain > hist[v]) {
        lowRemain -= hist[v];
        hist[v] = 0;
      } else {
        hist[v] -= lowRemain;
        lowRemain = 0;
      }
    }
    for (let v = 255; v >= 0 && highRemain > 0; v--) {
      if (highRemain > hist[v]) {
        highRemain -= hist[v];
        hist[v] = 0;
      } else {
        hist[v] -= highRemain;
        highRemain = 0;
      }
    }
    let low = 0;
    while (low < 256 && !hist[low]) low++;
    let high = 255;
    while (high >= 0 && !hist[high]) high--;
    const lut = new Uint8Array(256);
    if (high <= low) {
      for (let v = 0; v < 256; v++) lut[v] = v;
    } else {
      const slope = 255 / (high - low);
      const offset = -low * slope;
      for (let v = 0; v < 256; v++) {
        let out = Math.trunc(v * slope + offset);
        if (out < 0) out = 0;
        else if (out > 255) out = 255;
        lut[v] = out;
      }
    }
    for (let i = 0; i < total; i++) data[i * 4 + ch] = lut[data[i * 4 + ch]];
  }
}

function nearestPaletteColor(r, g, b, palette) {
  let best = palette[0];
  let bestDist = Infinity;
  for (const color of palette) {
    const dr = r - color[0];
    const dg = g - color[1];
    const db = b - color[2];
    const dist = dr * dr + dg * dg + db * db;
    if (dist < bestDist) {
      bestDist = dist;
      best = color;
    }
  }
  return best;
}

function quantizeImageData(imageData, palette, strength) {
  const d = imageData.data;
  const w = imageData.width;
  const h = imageData.height;
  const ditherScale = 255 * strength / 100;
  const rgb = palette.map(hexToRgb);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const offset = ((BAYER_8[y % 8][x % 8] + 0.5) / 64 - 0.5) * ditherScale;
      const idx = (y * w + x) * 4;
      const r = Math.max(0, Math.min(255, d[idx] + offset));
      const g = Math.max(0, Math.min(255, d[idx + 1] + offset));
      const b = Math.max(0, Math.min(255, d[idx + 2] + offset));
      const color = nearestPaletteColor(r, g, b, rgb);
      d[idx] = color[0];
      d[idx + 1] = color[1];
      d[idx + 2] = color[2];
      d[idx + 3] = 255;
    }
  }
}

function canvasToBlob(canvas) {
  return new Promise(function (resolve, reject) {
    canvas.toBlob(function (blob) {
      if (blob) resolve(blob);
      else reject(new Error("导出图片失败"));
    }, "image/png");
  });
}

async function convertToPixelArt(img, options) {
  const w = img.naturalWidth || img.width;
  const h = img.naturalHeight || img.height;
  if (!w || !h) throw new Error("图片无效或已损坏");

  const full = document.createElement("canvas");
  full.width = w;
  full.height = h;
  const ctx = full.getContext("2d");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  if (options.blurRadius > 0) ctx.filter = "blur(" + options.blurRadius + "px)";
  ctx.drawImage(img, 0, 0, w, h);
  ctx.filter = "none";

  const fullData = ctx.getImageData(0, 0, w, h);
  if (options.autoContrast) applyAutoContrast(fullData);
  ctx.putImageData(fullData, 0, 0);

  const cellW = Math.min(options.pixelWidth, w);
  const cellH = Math.max(1, Math.round(h * cellW / w));
  const small = document.createElement("canvas");
  small.width = cellW;
  small.height = cellH;
  const sctx = small.getContext("2d");
  sctx.imageSmoothingEnabled = true;
  sctx.imageSmoothingQuality = "high";
  sctx.drawImage(full, 0, 0, cellW, cellH);

  const smallData = sctx.getImageData(0, 0, cellW, cellH);
  quantizeImageData(smallData, options.palette, options.strength);
  sctx.putImageData(smallData, 0, 0);

  const outW = options.outputWidth;
  const outH = Math.max(1, Math.round(cellH * outW / cellW));
  const out = document.createElement("canvas");
  out.width = outW;
  out.height = outH;
  const octx = out.getContext("2d");
  octx.imageSmoothingEnabled = false;
  octx.drawImage(small, 0, 0, outW, outH);
  return canvasToBlob(out);
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1024 / 1024).toFixed(2) + " MB";
}

function computedOutputSize() {
  const w = state.natural.width;
  const h = state.natural.height;
  if (!w || !h) return null;
  const cellW = Math.min(state.options.pixelWidth, w);
  const cellH = Math.max(1, Math.round(h * cellW / w));
  const outH = Math.max(1, Math.round(cellH * state.options.outputWidth / cellW));
  return { width: state.options.outputWidth, height: outH };
}

function updateOutputLabel() {
  const size = computedOutputSize();
  if (size) {
    els.outputSizeLabel.textContent = size.width + " × " + size.height;
    els.resultSize.textContent = "输出 " + size.width + " × " + size.height + " px";
  } else {
    els.outputSizeLabel.textContent = "-";
    els.resultSize.textContent = "";
  }
}

function showError(message) {
  els.errorMsg.textContent = message;
  els.errorMsg.hidden = false;
}

function clearError() {
  els.errorMsg.hidden = true;
  els.errorMsg.textContent = "";
}

function setConverting(on, text) {
  if (on) {
    els.converting.textContent = text || "转换中…";
    els.converting.hidden = false;
  } else {
    els.converting.hidden = true;
  }
}

function setResult(blobUrl) {
  if (state.resultUrl) URL.revokeObjectURL(state.resultUrl);
  state.resultUrl = "";
  els.resultPreview.removeAttribute("src");
  els.resultPreview.hidden = true;
  els.resultEmpty.hidden = false;
  els.downloadBtn.disabled = true;
  if (blobUrl) {
    state.resultUrl = blobUrl;
    els.resultPreview.src = blobUrl;
    els.resultPreview.hidden = false;
    els.resultEmpty.hidden = true;
    els.downloadBtn.disabled = false;
  }
}

function syncSwatch(idx) {
  const color = state.palette[idx];
  if (!color) return;
  const swatch = els.paletteList.querySelector('.color-swatch[data-index="' + idx + '"]');
  const picker = els.paletteList.querySelector('.color-picker[data-index="' + idx + '"]');
  const hexInput = els.paletteList.querySelector('.color-hex[data-index="' + idx + '"]');
  if (swatch) swatch.style.setProperty("--swatch", color);
  if (picker) picker.value = color.toLowerCase();
  if (hexInput) hexInput.value = color.toUpperCase();
}

function renderPalette() {
  const html = [];
  state.palette.forEach(function (color, idx) {
    html.push('<div class="palette-slot">');
    html.push('<button type="button" class="color-swatch" data-index="' + idx + '" style="--swatch:' + color + '" aria-label="修改颜色 ' + (idx + 1) + '">' + (idx + 1) + "</button>");
    html.push('<input type="color" class="color-picker" data-index="' + idx + '" value="' + color.toLowerCase() + '" aria-label="颜色 ' + (idx + 1) + ' 选择器">');
    html.push('<input type="text" class="color-hex" data-index="' + idx + '" value="' + color.toUpperCase() + '" maxlength="7" spellcheck="false" aria-label="颜色 ' + (idx + 1) + ' 色值">');
    html.push('<button type="button" class="color-remove" data-index="' + idx + '" aria-label="移除颜色 ' + (idx + 1) + '">×</button>');
    html.push("</div>");
  });
  els.paletteList.innerHTML = html.join("");
  els.paletteList.classList.toggle("only-one", state.palette.length <= 1);
}

function applyExtractedPalette(colors) {
  const first = state.palette[0] || DEFAULT_PALETTE[0];
  const last = state.palette[state.palette.length - 1] || DEFAULT_PALETTE[DEFAULT_PALETTE.length - 1];
  const middle = colors.slice(0, 3).map(function (c) { return rgbToHex(c[0], c[1], c[2]); });
  state.palette = [first].concat(middle, [last]).slice(0, MAX_PALETTE);
  renderPalette();
}

let convertTimer = 0;
let mp4Supported = false;

function scheduleConvert() {
  window.clearTimeout(convertTimer);
  convertTimer = window.setTimeout(function () {
    if (state.mode === "video") refreshVideoFrame();
    else convert();
  }, 120);
}

async function convert(imgArg) {
  if (!state.file) return;
  const token = ++state.convertToken;
  setConverting(true);
  try {
    const img = imgArg || await loadImage(state.file);
    const blob = await convertToPixelArt(img, {
      palette: state.palette,
      pixelWidth: state.options.pixelWidth,
      outputWidth: state.options.outputWidth,
      strength: state.options.strength,
      blurRadius: state.options.blurRadius,
      autoContrast: state.options.autoContrast
    });
    if (token !== state.convertToken) return;
    setResult(URL.createObjectURL(blob));
    clearError();
    updateOutputLabel();
  } catch (err) {
    if (token === state.convertToken) showError(err && err.message ? err.message : "转换失败");
  } finally {
    if (token === state.convertToken) setConverting(false);
  }
}

async function autoExtract() {
  if (state.mode === "video") {
    const video = state.video.element;
    if (!state.video.file || !video || !video.videoWidth) return;
    setConverting(true, "提取颜色…");
    try {
      const colors = extractPaletteFromVideo(video, 3);
      if (colors.length >= 2) {
        applyExtractedPalette(colors);
        renderVideoFrameToCanvas(video, els.videoResult);
      } else {
        showError("未能从内容中提取足够的主色");
      }
    } catch (err) {
      showError(err && err.message ? err.message : "颜色提取失败");
    } finally {
      setConverting(false);
    }
    return;
  }
  if (!state.file) return;
  setConverting(true, "提取颜色…");
  try {
    const img = await loadImage(state.file);
    const colors = extractPaletteColors(img, 3);
    if (colors.length >= 2) {
      applyExtractedPalette(colors);
      await convert(img);
    } else {
      showError("未能从图片中提取足够的主色");
    }
  } catch (err) {
    showError(err && err.message ? err.message : "颜色提取失败");
  } finally {
    setConverting(false);
  }
}

async function handleFile(file) {
  if (!file) return;
  if (state.mode === "video") {
    await handleVideoFile(file);
    return;
  }
  clearError();
  if (!ACCEPTED_TYPES.includes(file.type)) {
    showError("仅支持 JPG、PNG、WEBP 图片");
    return;
  }
  if (file.size > IMAGE_MAX_SIZE) {
    showError("图片过大，请上传 5MB 以内的文件");
    return;
  }

  state.file = file;
  if (state.originalUrl) URL.revokeObjectURL(state.originalUrl);
  state.originalUrl = URL.createObjectURL(file);
  els.sourcePreview.src = state.originalUrl;
  els.sourcePreview.hidden = false;
  els.sourceName.textContent = file.name;
  els.sourceSize.textContent = formatBytes(file.size);
  els.sourceMeta.hidden = false;
  els.dropzone.classList.add("hidden");
  setResult(null);

  try {
    const img = await loadImage(file);
    state.natural = { width: img.naturalWidth, height: img.naturalHeight };
    updateOutputLabel();
    setConverting(true, "提取颜色…");
    const colors = extractPaletteColors(img, 3);
    if (colors.length >= 2) applyExtractedPalette(colors);
    await convert(img);
  } catch (err) {
    showError(err && err.message ? err.message : "转换失败");
  } finally {
    setConverting(false);
  }
}

async function handleVideoFile(file) {
  if (!VIDEO_TYPES.includes(file.type)) {
    showError("仅支持 MP4、WEBM、OGG 视频");
    return;
  }
  if (file.size > VIDEO_MAX_SIZE) {
    showError("视频过大，请上传 200MB 以内的文件");
    return;
  }
  clearError();
  stopVideoPreview();
  state.video.file = file;
  if (state.video.url) URL.revokeObjectURL(state.video.url);
  state.video.url = URL.createObjectURL(file);
  const video = state.video.element;
  video.src = state.video.url;
  video.hidden = false;
  els.sourcePreview.hidden = true;
  els.sourceMeta.hidden = false;
  els.sourceName.textContent = file.name;
  els.sourceSize.textContent = formatBytes(file.size);
  els.dropzone.classList.add("hidden");
  setResult(null);
  els.resultEmpty.hidden = true;
  els.videoResult.hidden = false;
  try {
    await loadVideoMeta(video);
    state.video.duration = video.duration || 0;
    state.video.width = video.videoWidth || 0;
    state.video.height = video.videoHeight || 0;
    state.natural = { width: state.video.width, height: state.video.height };
    updateOutputLabel();
    await waitSeeked(video, 0);
    setConverting(true, "提取颜色…");
    const colors = extractPaletteFromVideo(video, 3);
    if (colors.length >= 2) applyExtractedPalette(colors);
    renderVideoFrameToCanvas(video, els.videoResult);
    startVideoPreview();
    els.videoStatus.textContent = state.video.width + "×" + state.video.height + " · " + state.video.duration.toFixed(1) + "s";
  } catch (err) {
    showError(err && err.message ? err.message : "视频处理失败");
  } finally {
    setConverting(false);
  }
}

function getVideoSmallCanvas(cellW, cellH) {
  let small = state.video.small;
  if (!small) {
    small = document.createElement("canvas");
    state.video.small = small;
  }
  if (small.width !== cellW) small.width = cellW;
  if (small.height !== cellH) small.height = cellH;
  return small;
}

function renderVideoFrameToCanvas(video, targetCanvas) {
  const w = video.videoWidth || state.video.width;
  const h = video.videoHeight || state.video.height;
  if (!w || !h) return;
  const size = computedOutputSize();
  if (!size) return;
  if (targetCanvas.width !== size.width) targetCanvas.width = size.width;
  if (targetCanvas.height !== size.height) targetCanvas.height = size.height;

  const cellW = Math.min(state.options.pixelWidth, w);
  const cellH = Math.max(1, Math.round(h * cellW / w));
  const small = getVideoSmallCanvas(cellW, cellH);
  const sctx = small.getContext("2d");
  sctx.fillStyle = "#ffffff";
  sctx.fillRect(0, 0, cellW, cellH);
  sctx.imageSmoothingEnabled = true;
  sctx.imageSmoothingQuality = "high";
  sctx.drawImage(video, 0, 0, cellW, cellH);

  const data = sctx.getImageData(0, 0, cellW, cellH);
  if (state.options.autoContrast) applyAutoContrast(data);
  quantizeImageData(data, state.palette, state.options.strength);
  sctx.putImageData(data, 0, 0);

  const octx = targetCanvas.getContext("2d");
  octx.imageSmoothingEnabled = false;
  octx.clearRect(0, 0, targetCanvas.width, targetCanvas.height);
  octx.drawImage(small, 0, 0, targetCanvas.width, targetCanvas.height);
}



let previewRaf = 0;

function startVideoPreview() {
  if (previewRaf) return;
  const tick = function () {
    previewRaf = 0;
    if (state.mode !== "video" || !state.video.file) return;
    const video = state.video.element;
    if (video && video.readyState >= 2 && video.videoWidth) {
      renderVideoFrameToCanvas(video, els.videoResult);
    }
    previewRaf = requestAnimationFrame(tick);
  };
  previewRaf = requestAnimationFrame(tick);
}

function stopVideoPreview() {
  if (previewRaf) {
    cancelAnimationFrame(previewRaf);
    previewRaf = 0;
  }
}

function refreshVideoFrame() {
  const video = state.video.element;
  if (state.video.file && video && video.videoWidth) {
    renderVideoFrameToCanvas(video, els.videoResult);
  }
}

function downloadBlob(blob, filename) {
  window.__lastExportBlob = blob;
  window.__lastExportName = filename;
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
}

function pickWebMMime() {
  const candidates = [
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm;codecs=vp8",
    "video/webm"
  ];
  if (typeof MediaRecorder === "undefined") return "";
  for (const c of candidates) {
    try {
      if (MediaRecorder.isTypeSupported(c)) return c;
    } catch (e) {}
  }
  return "";
}

function pickMp4Mime() {
  const candidates = [
    "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
    "video/mp4;codecs=avc1.42E01E",
    "video/mp4"
  ];
  if (typeof MediaRecorder === "undefined") return "";
  for (const c of candidates) {
    try {
      if (MediaRecorder.isTypeSupported(c)) return c;
    } catch (e) {}
  }
  return "";
}

function updateExportSupport() {
  mp4Supported = !!pickMp4Mime();
  els.exportMp4Btn.disabled = !mp4Supported;
  els.exportMp4Btn.title = mp4Supported ? "" : "当前浏览器不支持 MP4 编码，可用 WebM 导出";
}

function setExporting(on, text) {
  els.exportProgress.hidden = !on;
  els.exportProgressText.textContent = text || "";
  els.exportWebMBtn.disabled = on;
  els.exportMp4Btn.disabled = on || !mp4Supported;
  els.exportFrameBtn.disabled = on;
  els.imageModeBtn.disabled = on;
  els.videoModeBtn.disabled = on;
}

async function exportVideo(extension) {
  const video = state.video.element;
  if (!state.video.file || !video || !video.duration || !isFinite(video.duration)) {
    showError("没有可导出的视频");
    return;
  }
  if (typeof MediaRecorder === "undefined") {
    showError("当前浏览器不支持 MediaRecorder");
    return;
  }
  const mime = extension === "mp4" ? pickMp4Mime() : pickWebMMime();
  if (!mime) {
    showError(extension === "mp4" ? "当前浏览器不支持 MP4 编码" : "当前浏览器不支持 WebM 编码");
    return;
  }
  setExporting(true, "正在录制 " + extension.toUpperCase() + "…");
  try {
    const size = computedOutputSize();
    const canvas = document.createElement("canvas");
    canvas.width = size.width;
    canvas.height = size.height;
    const stream = canvas.captureStream(30);
    let hasAudio = false;
    if (els.preserveAudio.checked && typeof video.captureStream === "function") {
      try {
        const vs = video.captureStream();
        const audioTracks = vs.getAudioTracks();
        audioTracks.forEach(function (t) { stream.addTrack(t); });
        hasAudio = audioTracks.length > 0;
      } catch (e) {}
    }
    const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 8000000 });
    const chunks = [];
    recorder.ondataavailable = function (e) {
      if (e.data && e.data.size) chunks.push(e.data);
    };
    const stopped = new Promise(function (resolve) { recorder.onstop = resolve; });
    const wasMuted = video.muted;
    if (hasAudio) video.muted = false;
    video.pause();
    await waitSeeked(video, 0);
    recorder.start(250);
    await video.play();
    const drawLoop = function () {
      if (video.readyState >= 2) renderVideoFrameToCanvas(video, canvas);
      if (!video.ended && recorder.state === "recording") requestAnimationFrame(drawLoop);
    };
    requestAnimationFrame(drawLoop);
    await new Promise(function (resolve) {
      if (video.ended) resolve();
      else video.addEventListener("ended", resolve, { once: true });
    });
    renderVideoFrameToCanvas(video, canvas);
    if (recorder.state !== "inactive") recorder.stop();
    await stopped;
    video.muted = wasMuted;
    downloadBlob(new Blob(chunks, { type: mime }), "pixel-video." + extension);
  } catch (err) {
    showError(err && err.message ? err.message : extension.toUpperCase() + " 导出失败");
  } finally {
    setExporting(false);
  }
}

function exportWebM() { return exportVideo("webm"); }

function exportMp4() { return exportVideo("mp4"); }








async function exportCurrentFrame() {
  const video = state.video.element;
  if (!state.video.file || !video || !video.videoWidth) {
    showError("没有可导出的视频帧");
    return;
  }
  setExporting(true, "导出当前帧…");
  try {
    const size = computedOutputSize();
    const canvas = document.createElement("canvas");
    canvas.width = size.width;
    canvas.height = size.height;
    renderVideoFrameToCanvas(video, canvas);
    const blob = await canvasToBlob(canvas);
    downloadBlob(blob, "pixel-frame.png");
  } catch (err) {
    showError(err && err.message ? err.message : "导出失败");
  } finally {
    setExporting(false);
  }
}

function clearCurrentSource() {
  stopVideoPreview();
  if (state.video.url) URL.revokeObjectURL(state.video.url);
  state.video.url = "";
  state.video.file = null;
  state.video.duration = 0;
  state.video.width = 0;
  state.video.height = 0;
  const v = state.video.element;
  if (v) {
    v.pause();
    v.removeAttribute("src");
    v.load();
    v.hidden = true;
  }
  if (state.originalUrl) URL.revokeObjectURL(state.originalUrl);
  state.originalUrl = "";
  state.file = null;
  els.sourcePreview.removeAttribute("src");
  els.sourcePreview.hidden = true;
  els.sourceMeta.hidden = true;
  els.dropzone.classList.remove("hidden");
  els.videoResult.hidden = true;
  els.videoStatus.textContent = "";
  setResult(null);
}

function applyModeUI(mode) {
  els.imageModeBtn.classList.toggle("active", mode === "image");
  els.videoModeBtn.classList.toggle("active", mode === "video");
  els.imageModeBtn.setAttribute("aria-pressed", String(mode === "image"));
  els.videoModeBtn.setAttribute("aria-pressed", String(mode === "video"));
  els.fileInput.accept = mode === "image" ? "image/jpeg,image/png,image/webp" : "video/mp4,video/webm,video/ogg";
  els.dropHint.textContent = mode === "image" ? "JPG / PNG / WEBP，最大 5MB" : "MP4 / WEBM / OGG，最大 200MB";
  els.imageExportRow.hidden = mode !== "image";
  els.videoExportRow.hidden = mode !== "video";
}

function setMode(mode) {
  if (state.mode === mode) return;
  clearCurrentSource();
  state.mode = mode;
  applyModeUI(mode);
}

els.dropzone.addEventListener("click", function () { els.fileInput.click(); });
els.dropzone.addEventListener("keydown", function (e) {
  if (e.key === "Enter" || e.key === " ") {
    e.preventDefault();
    els.fileInput.click();
  }
});
els.dropzone.addEventListener("dragover", function (e) {
  e.preventDefault();
  els.dropzone.classList.add("dragover");
});
els.dropzone.addEventListener("dragleave", function () {
  els.dropzone.classList.remove("dragover");
});
els.dropzone.addEventListener("drop", function (e) {
  e.preventDefault();
  els.dropzone.classList.remove("dragover");
  const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (file) handleFile(file);
});
els.fileInput.addEventListener("change", function () {
  const file = els.fileInput.files && els.fileInput.files[0];
  if (file) handleFile(file);
  els.fileInput.value = "";
});
els.chooseAgain.addEventListener("click", function () { els.fileInput.click(); });
els.chooseOther.addEventListener("click", function () { els.fileInput.click(); });
els.imageModeBtn.addEventListener("click", function () { setMode("image"); });
els.videoModeBtn.addEventListener("click", function () { setMode("video"); });

els.paletteList.addEventListener("click", function (e) {
  const swatch = e.target.closest(".color-swatch");
  const remove = e.target.closest(".color-remove");
  if (swatch) {
    const picker = els.paletteList.querySelector('.color-picker[data-index="' + swatch.dataset.index + '"]');
    if (picker) picker.click();
  }
  if (remove) {
    const idx = Number(remove.dataset.index);
    if (state.palette.length > 1) {
      state.palette.splice(idx, 1);
      renderPalette();
      scheduleConvert();
    }
  }
});

els.paletteList.addEventListener("input", function (e) {
  const picker = e.target.closest(".color-picker");
  if (picker) {
    const idx = Number(picker.dataset.index);
    state.palette[idx] = picker.value.toUpperCase();
    syncSwatch(idx);
    scheduleConvert();
  }
});

els.paletteList.addEventListener("change", function (e) {
  const hex = e.target.closest(".color-hex");
  if (hex) {
    const idx = Number(hex.dataset.index);
    const normalized = normalizeHex(hex.value);
    if (normalized) {
      state.palette[idx] = normalized;
      syncSwatch(idx);
      scheduleConvert();
    } else {
      hex.value = state.palette[idx].toUpperCase();
    }
  }
});

els.addColor.addEventListener("click", function () {
  const normalized = normalizeHex(els.addColorHex.value);
  if (!normalized) return;
  if (state.palette.length >= MAX_PALETTE) {
    showError("最多支持 12 个颜色");
    return;
  }
  state.palette.unshift(normalized);
  renderPalette();
  scheduleConvert();
});

els.addColorHex.addEventListener("keydown", function (e) {
  if (e.key === "Enter") els.addColor.click();
});

els.resetPalette.addEventListener("click", function () {
  state.palette = DEFAULT_PALETTE.slice();
  renderPalette();
  scheduleConvert();
});

els.extractPalette.addEventListener("click", autoExtract);

els.downloadBtn.addEventListener("click", function () {
  if (!state.resultUrl) return;
  const a = document.createElement("a");
  a.href = state.resultUrl;
  a.download = "pixel-art-" + new Date().toISOString().replace(/[:.]/g, "-") + ".png";
  document.body.appendChild(a);
  a.click();
  a.remove();
});

els.exportWebMBtn.addEventListener("click", exportWebM);
els.exportMp4Btn.addEventListener("click", exportMp4);
els.exportFrameBtn.addEventListener("click", exportCurrentFrame);

function bindSlider(input, output, key, formatter) {
  input.addEventListener("input", function () {
    state.options[key] = Number(input.value);
    output.textContent = formatter ? formatter(state.options[key]) : String(state.options[key]);
    updateOutputLabel();
    scheduleConvert();
  });
}

bindSlider(els.pixelWidth, els.pixelWidthVal, "pixelWidth");
bindSlider(els.outputWidth, els.outputWidthVal, "outputWidth");
bindSlider(els.strength, els.strengthVal, "strength", function (v) { return v + "%"; });
bindSlider(els.blur, els.blurVal, "blurRadius", function (v) { return Number(v.toFixed(1)); });

els.autoContrast.addEventListener("change", function () {
  state.options.autoContrast = els.autoContrast.checked;
  scheduleConvert();
});

applyModeUI("image");
updateExportSupport();
renderPalette();
updateOutputLabel();
