# 文件来源与第三方声明

本压缩包整理于 2026-09-27，用于迁移已验证的 Windows Unity CLI 环境。

## Unity CLI

`bin/unity.exe` 为本机已验证的 Unity CLI `1.0.0-beta.10` 原文件，本次打包未修改二进制。文件 SHA-256 和签名检查结果记录在 `manifest.json`。软件权利与适用条款仍属于其原权利人；这份迁移说明没有重新许可第三方程序。

## Unity Pipeline

`packages/com.unity.pipeline-0.7.0-exp.1.2022mod.1.tgz` 是基于 Unity Pipeline `0.7.0-exp.1` 的本地 Unity 2022 兼容版本，不是官方面向 Unity 2022 的发行版。

该 tgz 内保留了上游 `LICENSE.md`、`Third Party Notices.md`，以及本地 `UNITY-2022-COMPATIBILITY.md`。许可证及各依赖的第三方声明继续适用。修改后的包没有冒用上游原始包的签名或 attestation。

参考适配仓库：https://github.com/rocwood/unity-cli-2022-mod

上游 Pipeline 包来源：https://download.packages.unity.com/com.unity.pipeline/-/com.unity.pipeline-0.7.0-exp.1.tgz

## 本地辅助文件

`unity.ps1` 是可移动目录的调用脚本；`Verify-Files.ps1` 是本次迁移的文件校验工具。文档、清单和校验脚本不包含原电脑的登录状态或连接凭据。

