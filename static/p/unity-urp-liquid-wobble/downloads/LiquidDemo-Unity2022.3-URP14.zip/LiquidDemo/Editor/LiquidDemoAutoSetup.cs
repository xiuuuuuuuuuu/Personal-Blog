using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace LiquidDemo.Editor
{
    [InitializeOnLoad]
    internal static class LiquidDemoAutoSetup
    {
        private const string SceneName = "LiquidDemo";
        private const string Folder = "Assets/LiquidDemo";
        private const string GlassMaterialPath = Folder + "/Glass.mat";
        private const string LiquidMaterialPath = Folder + "/Liquid.mat";

        static LiquidDemoAutoSetup()
        {
            EditorApplication.delayCall += TrySetup;
            EditorSceneManager.sceneOpened += (_, _) => EditorApplication.delayCall += TrySetup;
        }

        [MenuItem("Tools/Liquid Demo/Configure Current Scene")]
        private static void ConfigureFromMenu()
        {
            SetupScene(true);
        }

        private static void TrySetup()
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling)
                return;

            Scene scene = SceneManager.GetActiveScene();
            if (!scene.IsValid() || scene.name != SceneName)
                return;

            SetupScene(false);
        }

        private static void SetupScene(bool showResult)
        {
            Scene scene = SceneManager.GetActiveScene();
            if (!scene.IsValid() || scene.name != SceneName)
            {
                if (showResult)
                    EditorUtility.DisplayDialog("Liquid Demo", "请先打开 LiquidDemo 场景。", "确定");
                return;
            }

            Shader liquidShader = Shader.Find("LiquidDemo/URP Liquid");
            Shader glassShader = Shader.Find("Universal Render Pipeline/Lit");
            if (liquidShader == null || glassShader == null)
                return;

            Transform cup = FindRoot(scene, "Cup") ?? FindRoot(scene, "Cylinder");
            if (cup == null)
            {
                if (showResult)
                    EditorUtility.DisplayDialog("Liquid Demo", "场景中没有找到根级 Cylinder。", "确定");
                return;
            }

            Transform liquid = cup.Find("Liquid");
            if (liquid == null)
            {
                foreach (Transform child in cup)
                {
                    if (child.name == "Cylinder")
                    {
                        liquid = child;
                        break;
                    }
                }
            }

            if (liquid == null)
            {
                if (showResult)
                    EditorUtility.DisplayDialog("Liquid Demo", "Cup 下没有找到子级 Cylinder。", "确定");
                return;
            }

            Material glassMaterial = LoadOrCreateGlass(glassShader);
            Material liquidMaterial = LoadOrCreateLiquid(liquidShader);

            Undo.RecordObject(cup.gameObject, "Configure liquid demo cup");
            Undo.RecordObject(liquid.gameObject, "Configure liquid demo liquid");
            cup.name = "Cup";
            liquid.name = "Liquid";

            Undo.RecordObject(liquid, "Fit liquid inside cup");
            liquid.localPosition = Vector3.zero;
            liquid.localRotation = Quaternion.identity;
            liquid.localScale = new Vector3(0.88f, 0.95f, 0.88f);

            Renderer cupRenderer = cup.GetComponent<Renderer>();
            Renderer liquidRenderer = liquid.GetComponent<Renderer>();
            if (cupRenderer != null)
            {
                Undo.RecordObject(cupRenderer, "Assign glass material");
                cupRenderer.sharedMaterial = glassMaterial;
                cupRenderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            }

            if (liquidRenderer != null)
            {
                Undo.RecordObject(liquidRenderer, "Assign liquid material");
                liquidRenderer.sharedMaterial = liquidMaterial;
                liquidRenderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            }

            CapsuleCollider liquidCollider = liquid.GetComponent<CapsuleCollider>();
            if (liquidCollider != null)
            {
                Undo.RecordObject(liquidCollider, "Disable liquid collider");
                liquidCollider.enabled = false;
            }

            if (liquid.GetComponent<LiquidWobble>() == null)
                Undo.AddComponent<LiquidWobble>(liquid.gameObject);
            if (cup.GetComponent<LiquidDemoMover>() == null)
                Undo.AddComponent<LiquidDemoMover>(cup.gameObject);

            EditorSceneManager.MarkSceneDirty(scene);
            EditorSceneManager.SaveScene(scene);
            AssetDatabase.SaveAssets();

            if (showResult)
                EditorUtility.DisplayDialog("Liquid Demo", "配置完成。点击 Play 即可查看液体晃动。", "确定");
        }

        private static Transform FindRoot(Scene scene, string objectName)
        {
            foreach (GameObject root in scene.GetRootGameObjects())
            {
                if (root.name == objectName)
                    return root.transform;
            }
            return null;
        }

        private static Material LoadOrCreateLiquid(Shader shader)
        {
            Material material = AssetDatabase.LoadAssetAtPath<Material>(LiquidMaterialPath);
            if (material != null)
                return material;

            material = new Material(shader)
            {
                name = "Liquid",
                renderQueue = 2990
            };
            material.SetColor("_BaseColor", new Color(0.02f, 0.42f, 0.80f, 0.82f));
            material.SetColor("_TopColor", new Color(0.08f, 0.70f, 1.00f, 0.96f));
            material.SetColor("_FoamColor", new Color(0.60f, 0.95f, 1.00f, 1f));
            AssetDatabase.CreateAsset(material, LiquidMaterialPath);
            return material;
        }

        private static Material LoadOrCreateGlass(Shader shader)
        {
            Material material = AssetDatabase.LoadAssetAtPath<Material>(GlassMaterialPath);
            if (material != null)
                return material;

            material = new Material(shader) { name = "Glass", renderQueue = 3000 };
            material.SetColor("_BaseColor", new Color(0.72f, 0.92f, 1f, 0.16f));
            material.SetFloat("_Surface", 1f);
            material.SetFloat("_Blend", 0f);
            material.SetFloat("_SrcBlend", (float)UnityEngine.Rendering.BlendMode.SrcAlpha);
            material.SetFloat("_DstBlend", (float)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            material.SetFloat("_ZWrite", 0f);
            material.SetFloat("_Smoothness", 0.92f);
            material.SetFloat("_Metallic", 0.05f);
            material.EnableKeyword("_SURFACE_TYPE_TRANSPARENT");
            material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            AssetDatabase.CreateAsset(material, GlassMaterialPath);
            return material;
        }
    }
}
