多语言文本查询工具 v0.1

1. 公司项目需已安装 Unity UI 和 TextMeshPro。
2. 导入 LocalizationTextQuery-v0.1.unitypackage（全部勾选）。
3. Unity 菜单：Tools > 多语言 > 查询有用文本。
4. 详细使用方法见 LocalizationTextQuery-v0.1-Guide.zh-CN.md。

已验证 Unity 2022.3.62f3；不需要 Unity CLI 或 Pipeline。
本版不包含 TMP 转 Text、公司 SDK 接入或译文回读。
