[CmdletBinding(PositionalBinding = $false)]
param(
    [string]$ProjectPath,
    [Parameter(ValueFromRemainingArguments = $true)][string[]]$CliArgs
)
$ErrorActionPreference = 'Stop'
$environmentNames = @('APPDATA','LOCALAPPDATA','UNITY_NO_BANNER','UNITY_NON_INTERACTIVE','UNITY_NO_PAGER','UNITY_NO_CLOUD')
$previousEnvironment = @{}
foreach ($name in $environmentNames) { $previousEnvironment[$name] = [Environment]::GetEnvironmentVariable($name, 'Process') }
try {
    $env:APPDATA = Join-Path $PSScriptRoot 'state/roaming'
    $env:LOCALAPPDATA = Join-Path $PSScriptRoot 'state/local'
    $env:UNITY_NO_BANNER = '1'
    $env:UNITY_NON_INTERACTIVE = '1'
    $env:UNITY_NO_PAGER = '1'
    $env:UNITY_NO_CLOUD = '1'
    New-Item -ItemType Directory -Force -Path $env:APPDATA,$env:LOCALAPPDATA | Out-Null
    if ($CliArgs.Count -gt 0 -and $CliArgs[0] -in @('command','cmd')) {
        if ($CliArgs | Where-Object { $_ -match '^--project-path(?:=|$)' }) {
            throw 'Use -ProjectPath with this wrapper, not --project-path.'
        }
        if (-not $ProjectPath) { $ProjectPath = (Get-Location).Path }
        $resolvedProject = (Resolve-Path -LiteralPath $ProjectPath).Path
        if (-not (Test-Path -LiteralPath (Join-Path $resolvedProject 'ProjectSettings/ProjectVersion.txt'))) {
            throw 'Specify a Unity project root using -ProjectPath.'
        }
        $CliArgs += @('--project-path', $resolvedProject)
    }
    elseif ($ProjectPath) {
        throw '-ProjectPath is supported for command/cmd calls only. Use the native command options for other operations.'
    }
    & (Join-Path $PSScriptRoot 'bin/unity.exe') @CliArgs
    $cliExitCode = $LASTEXITCODE
}
finally {
    foreach ($name in $environmentNames) { [Environment]::SetEnvironmentVariable($name, $previousEnvironment[$name], 'Process') }
}
exit $cliExitCode
